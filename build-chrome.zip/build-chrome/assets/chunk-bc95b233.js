import{j as e,d as a,b as d}from"./chunk-63f7b0b5.js";(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const t of r)if(t.type==="childList")for(const o of t.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function l(r){const t={};return r.integrity&&(t.integrity=r.integrity),r.referrerPolicy&&(t.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?t.credentials="include":r.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function s(r){if(r.ep)return;r.ep=!0;const t=l(r);fetch(r.href,t)}})();const c=()=>e.jsx("svg",{xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",role:"img",width:"2rem",height:"2rem",viewBox:"0 0 256 256",children:e.jsx("path",{fill:"currentColor",d:"m219.31 108.68l-80-80a16 16 0 0 0-22.62 0l-80 80A15.87 15.87 0 0 0 32 120v96a8 8 0 0 0 8 8h64a8 8 0 0 0 8-8v-56h32v56a8 8 0 0 0 8 8h64a8 8 0 0 0 8-8v-96a15.87 15.87 0 0 0-4.69-11.32M208 208h-48v-56a8 8 0 0 0-8-8h-48a8 8 0 0 0-8 8v56H48v-88l80-80l80 80Z"})}),h=a.div`
  padding: 1rem;
  width: 200px;
  z-index: 9999;
  display: grid;
  gap: 0.625rem;
  grid-template-columns: 2fr auto;
  grid-template-areas:
    'title home'
    'content content'
    'links links';
  color: white;

  .home {
    grid-area: home;
    color: white;
    width: 50%;
    height: 50%;
  }

  h3 {
    margin: 0;
    grid-area: title;
  }

  p {
    margin: 0;
    grid-area: content;
  }

  a {
    color: white;
    text-decoration: none;
    width: 100%;
  }

  ul {
    grid-area: links;
    list-style: none;
    padding: 0;
    width: 100%;
  }

  li {
    display: flex;
    justify-content: center;
    margin: 0.5rem 0;
    width: 100%;
  }

  .button-link {
    display: inline-block;
    padding: 0.5rem 1rem;
    background-color: #111628;
    border: none;
    border-radius: 4px;
    text-align: center;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s;
    border: 1px solid #344050;
    width: 100%;

    &:hover {
      background-color: rgba(226, 230, 234, 0.5);
    }
  }
`,u=()=>{const i="https://answers.mindenit.org";return e.jsxs(h,{children:[e.jsx("h3",{children:"Вітаємо вас у розширені Mindenit Answers!"}),e.jsx("p",{children:"Знаходьте відповіді ефективніше з нами! Зекономте час для більш важливих речей!❤️"}),e.jsx("a",{href:i,target:"_blank",rel:"noopener noreferrer",className:"home",children:e.jsx(c,{})}),e.jsxs("ul",{children:[e.jsx("h3",{children:"Якщо маєте змогу нас підтримати, то будемо раді будь яким пожертвуванням😉"}),e.jsx("li",{children:e.jsx("a",{href:"https://t.me/mindenit_support",className:"button-link",target:"_blank",rel:"noopener noreferrer",children:"Чат підтримки в телеграм 📨"})}),e.jsx("li",{children:e.jsx("a",{href:"https://send.monobank.ua/jar/2hMH9Gr7Dn",className:"button-link",target:"_blank",rel:"noopener noreferrer",children:"Монобанка 🐈"})}),e.jsx("li",{children:e.jsx("a",{href:"https://base.monobank.ua/DHfiSksgyjSYDT",className:"button-link",target:"_blank",rel:"noopener noreferrer",children:"Монобаза 💵"})})]})]})};d.createRoot(document.getElementById("app")).render(e.jsx(u,{}));
